pref("extensions.oneliness.boolpref", false);
pref("extensions.oneliness.intpref", 0);
pref("extensions.oneliness.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.hjsolbrig@yahoo.com.description", "chrome://oneliness/locale/overlay.properties");
